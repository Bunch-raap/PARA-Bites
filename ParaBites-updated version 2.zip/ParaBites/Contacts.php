<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $rating = $_POST['rating'];
    $message = $_POST['message'];

    // Server-side validation
    if (empty($name) || empty($email) || empty($message) || empty($rating)) {
        echo "All fields are required!";
        exit;
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format!";
        exit;
    }

    // Validate rating (should be between 1 and 5)
    if ($rating < 1 || $rating > 5) {
        echo "Rating must be between 1 and 5!";
        exit;
    }

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'parabites');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("INSERT INTO feedback (name, email, rating, message) VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        die("Prepare failed: " . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("ssis", $name, $email, $rating, $message);

    if ($stmt->execute()) {
        echo "Feedback submitted successfully!";
    } else {
        echo "Error: " . htmlspecialchars($stmt->error);
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review - PARA Bites</title>
    <link rel="stylesheet" href="styles.css">
    <style>
    
        .feedback-form {
            margin: auto;
        }
        .feedback-list {
            margin: 20px;
            border-top: 1px solid #ccc;
            padding-top: 20px;
        }
        .feedback-item {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }
        .rating {
            color: #ffcc00;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.jpg" alt="PARA Bites Logo">
        </div>
        <h1 style="font-size: 4em; margin: 0; color: #be5d00; margin-left: 10px;">PARA Bites</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home   | </a></li>
                <li><a href="bookings.php">Book a Table   | </a></li>
                <li><a href="view_booking.php">View Bookings  | </a></li>
                <li><a href="Contacts.php">Reviews  | </a></li>
				<li><a href="admin.php">Admin   | </a></li>
            </ul>
        </nav>
    </header>
    <section >
    <h2 style="text-align: center;color:white;font-size:3em;">Leave a Feedback</h2></br>

    <section class="section">
    <form action="Contacts.php" method="POST" class="feedback-form">
        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="email">Your Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="feedbackRating">Rating:</label>
        <div class="star-rating" id="feedbackRating">
            <input type="radio" name="rating" id="star5" value="5"><label for="star5">★</label>
            <input type="radio" name="rating" id="star4" value="4"><label for="star4">★</label>
            <input type="radio" name="rating" id="star3" value="3"><label for="star3">★</label>
            <input type="radio" name="rating" id="star2" value="2"><label for="star2">★</label>
            <input type="radio" name="rating" id="star1" value="1"><label for="star1">★</label>
        </div><br><br>

        <label for="message">Feedback:</label><br>
        <textarea id="message" name="message" rows="5" required></textarea><br><br>

        <input type="submit" value="Submit Feedback">
    </form>

</section>

    <section class="feedback-table">
        <h1>Customer Feedback</h1>
        <?php
        // Retrieve and display feedback from the database
        $conn = new mysqli('localhost', 'root', '', 'parabites');

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $result = $conn->query("SELECT name, email, rating, message, created_at FROM feedback ORDER BY created_at DESC");

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='customer-feedback'>";
                echo "<p><strong>" . htmlspecialchars($row['name']) . " (" . htmlspecialchars($row['email']) . ")</strong></p>";
                echo "<p class='rating'>" . str_repeat("★", $row['rating']) . str_repeat("☆", 5 - $row['rating']) . "</p>";
                echo "<p>" . nl2br(htmlspecialchars($row['message'])) . "</p>";
                echo "<small>Posted on " . htmlspecialchars($row['created_at']) . "</small>";
                echo "</div>";
            }
        } else {
            echo "<p>No feedback available yet. Be the first to leave your review!</p>";
        }

        $conn->close();
        ?>
    </section>

    <section class="menu" id="menu">
        <h1>Our Specialties</h1>
        <div class="menu-items">
            <div class="menu-item">
                <img src="momo.jpg" alt="Momo">
                <h3>Momo</h3>
                <p>Delicious Nepali dumplings.</p>
            </div>
            <div class="menu-item">
                <img src="Dal Bhat.jpg" alt="Dal Bhat">
                <h3>Dal Bhat</h3>
                <p>A traditional Nepali meal of rice and lentils.</p>
            </div>
            <div class="menu-item">
                <img src="choila.jpg" alt="Choila">
                <h3>Choila</h3>
                <p>Spicy grilled meat, a Newari delicacy.</p>
            </div>
        </div>
    </section>
<?php include 'footer.php'; ?>
</body>
</html>
