<?php
// Include the database connection file
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
    // Get form data
    $Tbl_Number = $_POST['table'];
    $Cus_Name = $_POST['name'];
    $Cus_Contact = $_POST['phone'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    // Insert booking into database
    $sql = "INSERT INTO bookings (Tbl_Number, Cus_Name, Cus_Contact, date, time)
            VALUES ('$Tbl_Number', '$Cus_Name', '$Cus_Contact', '$date', '$time')";

    if ($conn->query($sql) === TRUE) {
        echo "Table booked successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book a Table - PARA Bites</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
</head>
<body>

    <!-- Header Section -->
    <header>
        <div class="logo">
            <img src="logo.png" alt="Restaurant Logo"> <!-- Your logo file -->
            <h1>PARA Bites</h1>
        </div>
        <nav>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Menu</a></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#" class="btn">Book a Table</a></li> <!-- Call to action -->
            </ul>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <h1>Reserve Your Table</h1>
        <p>Experience the best dining at PARA Bites. Reserve your table now.</p>
        <a href="#booking-form" class="btn">Book Now</a>
    </section>

    <!-- Booking Form Section -->
    <section class="reservations">
        <h2>Book a Table</h2>
        <div class="booking-form" id="booking-form">
            <form action="submit_booking.php" method="POST"> <!-- Replace with your action -->
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" placeholder="Enter your full name" required>
                
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
                
                <label for="date">Reservation Date</label>
                <input type="date" id="date" name="date" required>
                
                <label for="time">Reservation Time</label>
                <input type="time" id="time" name="time" required>
                
                <label for="party-size">Party Size</label>
                <input type="number" id="party-size" name="party-size" placeholder="Enter number of guests" required>
                
                <input type="submit" value="Reserve Table">
            </form>
        </div>
    </section>

<?php include 'footer.php'; ?>
</body>
</html>
