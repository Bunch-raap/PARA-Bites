<?php
// Include the database connection file
include 'db.php';

// Initialize variables to store form data
$Tbl_Number = $Cus_Name = $Cus_Contact = $date = $time = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get form data
    $Tbl_Number = $_POST['guests'];
    $Cus_Name = $_POST['name'];
    $Cus_Contact = $_POST['email'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    // Insert booking into the database
    $sql = "INSERT INTO bookings (Tbl_Number, Cus_Name, Cus_Contact, date, time)
            VALUES ('$Tbl_Number', '$Cus_Name', '$Cus_Contact', '$date', '$time')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to the booking summary page with details in URL
        header("Location: bookingsummary.php?name=$Cus_Name&contact=$Cus_Contact&date=$date&time=$time&guests=$Tbl_Number");
        exit(); // Always call exit() after a redirect
    } else {
        // Booking failed, display error
        $errorMsg = "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book a Table</title>
    <link rel="stylesheet" href="styles.css"> <!-- Your existing CSS file -->
</head>
<body>

    <!-- Header Section -->
    <header>
        <div class="logo">
            <img src="logo.jpg" alt="PARA Bites Logo">
        </div>
        <h1 style="font-size: 4em; margin: 0; color: #ff7f00; margin-left: 10px;">PARA Bites</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home   | </a></li>
                <li><a href="bookings.php">Book a Table   | </a></li>
                <li><a href="view_booking.php">View Bookings  | </a></li>
                <li><a href="Contacts.php">Reviews  | </a></li>
                <li><a href="admin.php">Admin   | </a></li>
            </ul>
        </nav>
    </header>

    <!-- Reservation Form Section -->
      
            <section class="booking-section">
                <div class="booking-form">
                <section class="table1" id="table1">
                  <div class="table1-content">
                    <h1>Book a Table</h1>
                    <form action="bookings.php" method="post">
                        <label for="name">Your Name</label>
                        <input type="text" id="name" name="name" placeholder="Enter your name" required>

                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" placeholder="Enter your email" required>

                        <label for="date">Reservation Date</label>
                        <input type="date" id="date" name="date" required>

                        <label for="time">Reservation Time</label>
                        <input type="time" id="time" name="time" required>

                        <label for="guests">Number of Guests</label>
                        <input type="number" id="guests" name="guests" placeholder="Enter number of guests" min="1" required>

                        <input type="submit" value="Book Now">
                    </form>
                </div>
            </section>
        </div>
    </section>
    <section class="menu" id="menu">
        <h1>Our Specialties</h1></br>
        <div class="menu-items">
            <div class="menu-item">
                <img src="momo.jpg" alt="Momo">
                <h3>Momo</h3>
                <p>Delicious Nepali dumplings.</p>
            </div>
            <div class="menu-item">
                <img src="Dal Bhat.jpg" alt="Dal Bhat">
                <h3>Dal Bhat</h3>
                <p>A traditional Nepali meal of rice and lentils.</p>
            </div>
            <div class="menu-item">
                <img src="choila.jpg" alt="Choila">
                <h3>Choila</h3>
                <p>Spicy grilled meat, a Newari delicacy.</p>
            </div>
        </div>
    </section>

    <?php include 'footer.php'; ?>
</body>
</html>
