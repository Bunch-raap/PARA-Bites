<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $rating = $_POST['rating'];
    $message = $_POST['message'];

    // Server-side validation
    if (empty($name) || empty($email) || empty($message) || empty($rating)) {
        echo "All fields are required!";
        exit;
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format!";
        exit;
    }

    // Validate rating (should be between 1 and 5)
    if ($rating < 1 || $rating > 5) {
        echo "Rating must be between 1 and 5!";
        exit;
    }

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'parabites');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("INSERT INTO feedback (name, email, rating, message) VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        die("Prepare failed: " . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("ssis", $name, $email, $rating, $message);

    if ($stmt->execute()) {
        echo "Feedback submitted successfully!";
    } else {
        echo "Error: " . htmlspecialchars($stmt->error);
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review - PARA Bites</title>
    <link rel="stylesheet" href="styles.css">
    <style>
       
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.jpg" alt="PARA Bites Logo">
        </div>
        <h1 style="font-size: 4em; margin: 0; color: #be5d00; margin-left: 10px;">PARA Bites</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home   | </a></li>
                <li><a href="bookings.php">Book a Table   | </a></li>
                <li><a href="view_booking.php">View Bookings  | </a></li>
                <li><a href="feedback.php">Reviews  | </a></li>
                <li><a href="admin.php">Admin   | </a></li>
            </ul>
        </nav>
    </header>
    <section>
        <h2>Leave a Feedback</h2>
        <form action="feedback.php" method="POST" class="feedback-form">
            <label for="name">Your Name:</label>
            <input type="text" id="name" name="name" required><br><br>

            <label for="email">Your Email:</label>
            <input type="email" id="email" name="email" required><br><br>

   <label for="feedbackRating">Rating:</label>
    <div class="star-rating" id="feedbackRating">
        <input type="radio" name="rating" id="star5" value="5"><label for="star5">★</label>
        <input type="radio" name="rating" id="star4" value="4"><label for="star4">★</label>
        <input type="radio" name="rating" id="star3" value="3"><label for="star3">★</label>
        <input type="radio" name="rating" id="star2" value="2"><label for="star2">★</label>
        <input type="radio" name="rating" id="star1" value="1"><label for="star1">★</label>
    </div><br><br>

            <label for="message">Feedback:</label><br>
            <textarea id="message" name="message" rows="5" required></textarea><br><br>

            <input type="submit" value="Submit Feedback">
        </form>
    </section>

    <section class="customer-feedback">
    <h2>Customer Feedback</h2>
    <?php
    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'parabites');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch feedback from the database
    $result = $conn->query("SELECT name, email, rating, message, created_at FROM feedback ORDER BY created_at DESC");

    if ($result->num_rows > 0) {
        echo "<table class='feedback-table'>";
        echo "<thead><tr><th>Name</th><th>Email</th><th>Rating</th><th>Feedback</th><th>Date</th></tr></thead>";
        echo "<tbody>";

        // Loop through feedback and display in table rows
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['email']) . "</td>";
            echo "<td class='rating'>" . str_repeat("★", $row['rating']) . str_repeat("☆", 5 - $row['rating']) . "</td>";
            echo "<td>" . nl2br(htmlspecialchars($row['message'])) . "</td>";
            echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
            echo "</tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<p>No feedback available yet. Be the first to leave your review!</p>";
    }

    $conn->close();
    ?>
</section>
    <section class="menu" id="menu">
        <h1>Our Specialties</h1></br>
        <div class="menu-items">
            <div class="menu-item">
                <img src="momo.jpg" alt="Momo">
                <h3>Momo</h3>
                <p>Delicious Nepali dumplings.</p>
            </div>
            <div class="menu-item">
                <img src="Dal Bhat.jpg" alt="Dal Bhat">
                <h3>Dal Bhat</h3>
                <p>A traditional Nepali meal of rice and lentils.</p>
            </div>
            <div class="menu-item">
                <img src="choila.jpg" alt="Choila">
                <h3>Choila</h3>
                <p>Spicy grilled meat, a Newari delicacy.</p>
            </div>
        </div>
    </section>
<?php include 'footer.php'; ?>
</body>
</html>
