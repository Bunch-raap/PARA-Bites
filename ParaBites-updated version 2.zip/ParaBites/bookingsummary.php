<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Summary</title>
    <link rel="stylesheet" href="styles.css"> <!-- Your existing CSS file -->
    <style>
        /* Add styling for the summary box */
        .summary-box {
            border: 4px solid #be5d00;
            padding: 70px;
            margin-top: 40px;
            background-color: #f9f9f9;
            max-width: 500px;
            margin: 0 auto;
            text-align: center-align ;
            align-items: center;
      
            
        }
        .summary-box h2 {
            margin-bottom: 20px;
            color: #be5d00;
        }
        .summary-box p {
            margin: 5px 0;
        }
    </style>
</head>
<body>

    <!-- Header Section -->
    <header>
        <div class="logo">
            <img src="logo.jpg" alt="PARA Bites Logo">
        </div>
        <h1 style="font-size: 4em; margin: 0; color: #ff7f00; margin-left: 10px;">PARA Bites</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home   | </a></li>
                <li><a href="bookings.php">Book a Table   | </a></li>
                <li><a href="view_booking.php">View Bookings  | </a></li>
                <li><a href="Contacts.php">Reviews  | </a></li>
                <li><a href="admin.php">Admin   | </a></li>
            </ul>
        </nav>
    </header></br></br>

    <!-- Booking Summary Section -->
    <div class="summary-box">
        <h2>Successfully Booked</h2>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($_GET['name']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($_GET['contact']); ?></p>
        <p><strong>Reservation Date:</strong> <?php echo htmlspecialchars($_GET['date']); ?></p>
        <p><strong>Reservation Time:</strong> <?php echo htmlspecialchars($_GET['time']); ?></p>
        <p><strong>Number of Guests:</strong> <?php echo htmlspecialchars($_GET['guests']); ?></p>
    </div></br></br>

    <section class="menu" id="menu">
        <h1>Our Specialties</h1><br>
        <div class="menu-items">
            <div class="menu-item">
                <img src="momo.jpg" alt="Momo">
                <h3>Momo</h3>
                <p>Delicious Nepali dumplings.</p>
            </div>
            <div class="menu-item">
                <img src="Dal Bhat.jpg" alt="Dal Bhat">
                <h3>Dal Bhat</h3>
                <p>A traditional Nepali meal of rice and lentils.</p>
            </div>
            <div class="menu-item">
                <img src="choila.jpg" alt="Choila">
                <h3>Choila</h3>
                <p>Spicy grilled meat, a Newari delicacy.</p>
            </div>
        </div>
    </section>

    <?php include 'footer.php'; ?>
</body>
</html>