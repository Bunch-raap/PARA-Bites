<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nepali Restaurant - PARA Bites</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
	    <div class="logo">
            <img src="logo.jpg" alt="PARA Bites Logo">
        </div>
        <h1 style="font-size: 4em; margin: 0; color: #ff7f00; margin-left: 10px;">PARA Bites</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home   | </a></li>
                <li><a href="bookings.php">Book a Table   | </a></li>
                <li><a href="view_booking.php">View Bookings  | </a></li>
                <li><a href="Contacts.php">Reviews  | </a></li>
				<li><a href="admin.php">Admin  | </a></li>
            </ul>
        </nav>
    </header>

<section class="hero" id="home">
    <div class="hero-content">
        <h1>Welcome to PARA Bites</h1>
        <p>Authentic Nepali Cuisine</p>
        <a href="#menu" class="btn">Explore Menu</a>
    </div>
</section>


    <section class="menu" id="menu">
        <h1>Our Specialties</h1>
        <div class="menu-items">
            <div class="menu-item">
                <img src="momo.jpg" alt="Momo">
                <h3>Momo</h3>
                <p>Delicious Nepali dumplings.</p>
            </div>
            <div class="menu-item">
                <img src="Dal Bhat.jpg" alt="Dal Bhat">
                <h3>Dal Bhat</h3>
                <p>A traditional Nepali meal of rice and lentils.</p>
            </div>
            <div class="menu-item">
                <img src="choila.jpg" alt="Choila">
                <h3>Choila</h3>
                <p>Spicy grilled meat, a Newari delicacy.</p>
            </div>
        </div>
    </section>

<?php include 'footer.php'; ?>
</body>
</html>
